rootProject.name = "SulJabPlugin"
